Firebird AVR hardware package 1.0.1
FQBN: firebird:avr:firebird2560
