Firebird AVR hardware package 1.0.2
FQBN: firebird:avr:firebird2560
